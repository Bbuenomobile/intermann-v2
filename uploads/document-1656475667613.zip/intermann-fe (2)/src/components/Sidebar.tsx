import React, { useState } from "react";
import { Link } from "react-router-dom";
import '../CSS/Sidebar.css';
import Header from "./Header";
import { useDispatch } from "react-redux";
import { useNavigate } from "react-router-dom";
import { Toaster, toast } from 'react-hot-toast';
import { logout } from '../redux/actions/userActions'
function Sidebar(props: any) {
  const dispatch = useDispatch();
  const navigate = useNavigate()
  const LogNotify = () => toast("Log-Out!");

  const LogOut = async () => {
    await dispatch(logout())
    await localStorage.removeItem("token")
    navigate('/')
    LogNotify()
  }
  return (
    <>
      <div className="container-fluid" style={{ height: "100%", backgroundColor: "white" }}>
        <div className="row" >

          <div className="col-lg-3 col-md-3 col-xs-3 fixed pd-gutter" style={{ height: "100vh", backgroundColor: "white" }}>
            <div
              className="d-flex flex-column flex-shrink-0"
            >
              <Link
                to="/dashboard"
                className="d-flex bottom-radius logoSet align-items-center mb-3 mb-md-0 me-md-auto link-dark text-decoration-none"
              ><span>
                  <img src={require("../images/logo-header.svg").default} />
                </span>
                <img src={require("../images/LogoName.svg").default} />
              </Link>

              <ul className="nav nav-pills flex-column mb-auto text-className">
                <li className="nav-item">
                  <Link to="#" className="nav-link pd013" aria-current="page">
                    <span className="pe-2">
                      <img src={require("../images/Shape.svg").default} />
                    </span>
                    Résumé
                  </Link>
                </li>

                <div className="accordion accordion-flush" id="accordionFlushExample">

                  <div className="accordion-item">
                    <h2 className="accordion-header" id="flush-headingTwo">
                      <button className="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#flush-collapseTwo" aria-expanded="false" aria-controls="#flush-collapseTwo">
                        <span className="pe-2">
                          <img src={require("../images/Combine.svg").default} />
                        </span>
                        Leads  / Clients
                      </button>
                    </h2>
                    <div id="flush-collapseTwo" className="accordion-collapse collapse " aria-labelledby="flush-headingTwo" data-bs-parent="#accordionFlushExample">
                      <div className="accordion-body">
                        <ul>
                          <li>
                            <div className="row">
                              <div className="col-2">
                                <Link to="/clientTodo" className="nav-link link-dark FontStylingBar">
                                  <span className="pe-2">
                                    <img src={require("../images/todoList.svg").default} />
                                  </span>
                                </Link>
                              </div>
                              <div className="col-8">
                                <p style={{ cursor: "pointer", fontSize: '15px' }}>To do / Non traité / Attente</p>
                              </div>
                            </div>
                          </li>
                          <li>
                            <div className="row">
                              <div className="col-2">
                                <Link to="/clientProgress" className="nav-link link-dark FontStylingBar">
                                  <span className="pe-2">
                                    <img src={require("../images/analytics.svg").default} />
                                  </span>
                                </Link>
                              </div>
                              <div className="col-8">
                                <p style={{ cursor: 'pointer', fontSize: '15px' }}>En cours de Recherche</p>
                              </div>
                            </div>
                          </li>
                          <li>
                            <div className="row">
                              <div className="col-2">
                                <Link to="/clientContract" className="nav-link link-dark FontStylingBar">
                                  <span className="pe-2">
                                    <img src={require("../images/contractList.svg").default} />
                                  </span>

                                </Link>
                              </div>
                              <div className="col-8">
                                <p style={{ cursor: 'pointer', fontSize: '15px' }}>Terminé / Contrat en cours</p>
                              </div>
                            </div>

                          </li>
                          <div className="row">
                            <div className="col-2">
                              <Link to="/archivedClientList" className="nav-link link-dark FontStylingBar">
                                <span className="pe-2">
                                  <img src={require("../images/archivedList.svg").default} />
                                </span>
                              </Link>
                            </div>
                            <div className="col-8">
                              <p className="mt-2" style={{ cursor: 'pointer', fontSize: '15px' }}>Annulé / Archivé</p>
                            </div>
                          </div>
                          <li>

                          </li>
                        </ul>
                      </div>
                    </div>
                  </div>
                  <div className="accordion-item">
                    <h2 className="accordion-header" id="flush-headingThree">
                      <button className="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#flush-collapseThree" aria-expanded="false" aria-controls="flush-collapseThree">
                        <span className="pe-2">
                          <img src={require("../images/employeeicon.svg").default} />
                        </span>
                        Candidats / Employés
                      </button>
                    </h2>
                    <div id="flush-collapseThree" className="accordion-collapse collapse" aria-labelledby="flush-headingThree" data-bs-parent="#accordionFlushExample">
                      <div className="accordion-body">
                        <ul>
                          <li>
                            <div className="row">
                              <div className="col-2">
                                <Link to="/todolist" className="nav-link link-dark FontStylingBar">
                                  <span className="pe-2">
                                    <img src={require("../images/list-text.svg").default} />
                                  </span>

                                </Link>
                              </div>
                              <div className="col-8">
                                <p style={{ cursor: 'pointer', fontSize: '15px', marginTop: '10px' }}> En sommeil</p>
                              </div>
                            </div>

                          </li>
                          <li>
                            <div className="row">
                              <div className="col-2"></div>
                              <div className="col-8"></div>
                            </div>

                          </li> <li>
                            <Link to="/archivedlist" className="nav-link link-dark FontStylingBar">
                              <span className="pe-2">
                                <img src={require("../images/archivedList.svg").default} />
                              </span>
                              Archivé
                            </Link>
                          </li></ul>
                      </div>
                    </div>
                  </div>
                  <div className="accordion-item">
                    <h2 className="accordion-header" id="flush-headingOne">
                      <button className="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#flush-collapseOne" aria-expanded="false" aria-controls="flush-collapseOne">
                        <span className="pe-2">
                          <img src={require("../images/settings.svg").default} />
                        </span>
                        Manage
                      </button>
                    </h2>
                    <div id="flush-collapseOne" className="accordion-collapse collapse " aria-labelledby="flush-headingOne" data-bs-parent="#accordionFlushExample">
                      <div className="accordion-body">
                        <ul>  <li>
                          <Link to="/addNewSector" className="nav-link FontStylingBar" aria-current="page">
                            <span className="pe-2">
                              <img src={require("../images/addsector.svg").default} />
                            </span>
                            Add New Sector
                          </Link>
                        </li>
                          <li>
                            <Link to="/userList" className="nav-link FontStylingBar" aria-current="page">
                              <span className="pe-2">
                                <img src={require("../images/adduser.svg").default} />
                              </span>
                              User List
                            </Link>
                          </li>
                        </ul>
                      </div>
                    </div>
                  </div>
                </div>
                <li className="nav-item text-center Log-Out" onClick={(e) => LogOut()}>
                  <Link to="/" className="nav-link" aria-current="page">
                    <span className="pe-2">
                      <img className="logoutImage" src={require("../images/logout.svg").default} />
                    </span>
                    Sign Out
                    <Toaster
                      position="top-right"
                    />
                  </Link>
                </li>

              </ul>
            </div>
          </div>
          <div className="col-lg-9 col-md-9 col-xs-9 scroll">
            <Header />
            <section style={{ marginTop: "60px" }}>
              {props.children}
            </section >
          </div>
        </div>
      </div>

    </>
  );
}
export default Sidebar;
