import React, { useEffect, useState } from 'react';
import { toast, Toaster } from "react-hot-toast";
import { useNavigate } from 'react-router-dom';
import { API_BASE_URL } from '../../config/serverApiConfig';


function AddJobModal({ props, closeModal }) {

  const notifyJobAddSuccess = () => toast.success("Job Added Successfully! You can Add More Jobs to this Sector");
  const notifyJobAddError = () => toast.error("Job Already Exists! Please Add another.");

  const notifyGeneralError = () => toast.error("Job Add Failed! Please Try Again.");
  const notifyJobBlankError = () => toast.error("Job Name Can't Be Blank.");


  const [jobName, setJobName] = useState("");

  const checkJobExistence = async () => {
    return await fetch(API_BASE_URL + `checkJobExistence/?sector=${props}&job=` + jobName, {
      method: "GET",
      headers: {
        "Accept": 'application/json',
        'Content-Type': 'application/json',
        "Authorization": "Bearer " + localStorage.getItem('token')
      },
    })
      .then(resp => resp.json())
      .then(data => data)
      .catch(err => err)
  }

  const handleJobInputChange = (e: any) => {
    console.log(e.target.value);
    setJobName(e.target.value);
  }

  const checkandaddJob = () => {

    if (jobName != "") {
      checkJobExistence()
        .then(resD => {
          console.log(resD)
          if (resD.status) {
            notifyJobAddSuccess()
            window.location.href = "/addNewSector";
          } else {
            notifyJobAddError()
            window.location.href = "/addNewSector";

          }
        })
        .catch(err => {
          console.log(err)
          notifyGeneralError();
          window.location.href = "/addNewSector";

        })
    } else {
      notifyJobBlankError();
    }
  }

  return (
    <>
      <Toaster position='top-right' />
      <div className="modal d-block" id="addJobModal" aria-labelledby="exampleModalLabel" aria-hidden="true" style={{ backgroundColor: "#00000052" }}>
        <div className="modal-dialog">
          <div className="modal-content">
            <div className="modal-header">
              <h5 className="modal-title" id="exampleModalLabel">Add A Job To Sector - {props}</h5>
              <button type="button" className="btn-close" data-bs-dismiss="modal" aria-label="Close" onClick={() => { closeModal(false) }}></button>
            </div>
            <div className="modal-body text-center">
              <input type="text" name="jobName" className='form-control' onChange={handleJobInputChange} placeholder='Enter A Job...' />
            </div>
            <div className="modal-footer">
              <button type="button" className="btn btn-secondary" data-bs-dismiss="modal" onClick={() => { closeModal(false) }}>Cancel</button>
              <button type="button" className="btn btn-primary" onClick={checkandaddJob}>Add Job</button>
            </div>
          </div>
        </div>
      </div>
    </>
  )
}
export default AddJobModal;