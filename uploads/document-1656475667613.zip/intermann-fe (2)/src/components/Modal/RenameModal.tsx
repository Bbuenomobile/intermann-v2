import React, { useState } from 'react';
import { toast, Toaster } from "react-hot-toast";
import { API_BASE_URL } from '../../config/serverApiConfig';

function RenameModal({ props, closeModal }) {
    console.log(props)
    const [newSectorName, setNewSectorName] = useState("");

    const notifySectorRenameSuccess = () => toast.success("Sector Renamed Successfully! You can Add More Jobs to this Sector");
    const notifySectorRenameError = () => toast.error("Cannot Be Renamed! Please Try Again.");

    const notifyGeneralError = () => toast.error("Sector Rename Failed! Please Try Again.");

    const notifySectorBlankError = () => toast.error("Sector Name Can't Be Blank.");


    const handleSectorNameChange = (e: any) => {
        setNewSectorName(e.target.value);
    }

    const sendNewNameToDB = () => {
        return fetch(API_BASE_URL + "updateSector", {
            method: "POST",
            headers: {
                "Accept": 'application/json',
                'Content-Type': 'application/json',
                "Authorization": "Bearer " + localStorage.getItem('token')
            },
            body: JSON.stringify({
                currentName: props,
                newName: newSectorName
            })
        })
            .then(resp => resp.json())
            .then(resD => resD)
            .catch(err => err);
    }

    const saveNewSectorName = () => {
        if (newSectorName != "") {
            sendNewNameToDB().then(data => {
                console.log(data)
                if (data.status) {
                    notifySectorRenameSuccess();
                    window.location.href = "/addNewSector";
                } else {
                    notifySectorRenameError();
                }
            })
                .catch(err => {
                    console.log(err)
                })
        } else {
            notifySectorBlankError();
        }

    }

    return (<>
        <Toaster position='top-right' />
        <div className="modal d-block" id="renameModal" style={{ backgroundColor: "#00000052" }} aria-labelledby="exampleModalLabel" aria-hidden="true">
            <div className="modal-dialog">
                <div className="modal-content">
                    <div className="modal-header">
                        <h5 className="modal-title" id="exampleModalLabel">Rename Sector - {props}</h5>
                        <button type="button" className="btn-close" data-bs-dismiss="modal" aria-label="Close" onClick={() => closeModal(false)}></button>
                    </div>
                    <div className="modal-body text-center">
                        <input type="text" name="sectorName" onChange={handleSectorNameChange} className='form-control' placeholder={'Enter New Name for Sector - ' + props} />
                    </div>
                    <div className="modal-footer">
                        <button type="button" className="btn btn-secondary" data-bs-dismiss="modal" onClick={() => closeModal(false)}>Cancel</button>
                        <button type="button" className="btn btn-primary" onClick={saveNewSectorName}>Save Changes To Sector Name</button>
                    </div>
                </div>
            </div>
        </div>
    </>)
}
export default RenameModal;