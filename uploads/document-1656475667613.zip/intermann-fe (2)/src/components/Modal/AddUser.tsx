import React, { useState } from "react";
import '../../CSS/AddSector.css'
import { API_BASE_URL } from "../../config/serverApiConfig"
import { Toaster, toast } from 'react-hot-toast';
import { useNavigate } from "react-router-dom";


function UserAddModal({ closeModal }) {


  const [emailAddress, setEmailAddress] = useState("");
  const [password, setPassword] = useState("");
  const [res, setResponse] = useState([])
  const data = {
    emailAddress: emailAddress,
    password: password
  }

  const navigate = useNavigate();
  const AddSuccess = () => toast.success("Successfully Added User!");
  const AddFailure = () => toast.error("User Registration Failed! Please Try Again.");
  const UserExists = () => toast.error("User Already Exists! Add a New User.");
  const BlankFailure = () => toast.error("Fields Cannot Be Blank! Please Enter Valid Information.");


  const signupUser = async () => {
    return await fetch(API_BASE_URL + "signup", {
      method: "POST",
      headers: {
        "Accept": 'application/json',
        'Content-Type': 'application/json',
        "Authorization": "Bearer " + localStorage.getItem('token')
      },
      body: JSON.stringify({ ...data }),
    })
      .then(resp => resp.json())
      .then(reD => reD)
      .catch(err => err)
  }

  const saveUserData = async () => {
    console.log(data)
    if (data.emailAddress != "" && data.password != "") {
      signupUser()
        .then(datares => {
          console.log(datares)
          if (datares.status) {
            AddSuccess()
            setTimeout(() => {
              window.location.href = "/userList";
            }, 1000);
          } else {
            UserExists();
          }
        })
        .catch(err => {
          console.log(err)
          AddFailure();
        })
    } else {
      BlankFailure();
    }
  }


  return (
    <>
      <Toaster position="top-right" />
      <div
        className="modal d-block"
        id="addJobModal"
        aria-labelledby="exampleModalLabel"
        aria-hidden="true"
        style={{ backgroundColor: "#00000052" }}
      >

        <div className="modal-dialog">
          <div className="modal-content">
            <div className="modal-header">
              <h5 className="modal-title" id="exampleModalLabel">
                Add user
              </h5>
              <button
                type="button"
                className="btn-close"
                data-bs-dismiss="modal"
                aria-label="Close"
                onClick={(e) => {
                  closeModal(false);
                }}
              ></button>
            </div>
            <div className="modal-body  text-start">
              <label className="form-label mb-0 fs-6">Email</label>
              <input
                type="email"
                name="email"
                className="form-control"
                onChange={(e) => {
                  setEmailAddress(e.target.value);
                }}
                placeholder="Enter email..."
                autoComplete="off"
              />
              <div className="mt-2">
                <label
                  htmlFor="validationCustom02"
                  className="form-label mb-0 fs-6"
                >
                  Password
                </label>
                <input
                  type="password"
                  name="password"
                  id="validationCustom02"
                  className="form-control"
                  onChange={(e) => {
                    setPassword(e.target.value);
                  }}
                  placeholder="Enter password..."
                  autoComplete="off"
                />
              </div>
            </div>

            <div className="modal-footer">
              <div className="col-12">
                <div className="row">
                  <div className="col-12">
                    <button
                      type="button"
                      className="btn btn-addUser"
                      onClick={() => saveUserData()}
                    >
                      Add User
                    </button>
                  </div>

                </div>
              </div>

            </div>
          </div>

        </div>

      </div>
    </>
  );
}
export default UserAddModal;
