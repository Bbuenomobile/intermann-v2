import * as LottiePlayer from "@lottiefiles/lottie-player";

function Loader() {

    return (
        <>
            <lottie-player src="https://assets4.lottiefiles.com/packages/lf20_jsuj2bs7.json" speed="1" style={{ width: "300px", height: "300px", background: "transparent" }} loop autoplay></lottie-player>
        </>
    )
}
export default Loader;