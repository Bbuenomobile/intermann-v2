import { combineReducers } from 'redux';
import loginReducer from './Loginauth/loginReducer';

const rootReducer = combineReducers({
   loginReducer
});

export default rootReducer;