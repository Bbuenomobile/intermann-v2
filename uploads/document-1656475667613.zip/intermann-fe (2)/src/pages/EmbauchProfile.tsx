import React, { useEffect, useState } from "react";
import StarRatings from "react-star-ratings";
import { Link } from "react-router-dom";
import "../CSS/inProgressCard.css";
import { useLocation } from 'react-router-dom';
import { useNavigate } from "react-router-dom";
import { API_BASE_URL } from "../config/serverApiConfig";
import ArchivedModal from "../components/ArchivedModal";

function ProgressCard() {

  const { state } = useLocation();

  const navigate = useNavigate();
  const [modalIsOpen, setModalIsOpen] = useState(false);
  const [profile, setProfile] = useState<any>(state);
  const [showArchiveModal, setShowArchiveModal] = useState(false)
  const [clientProfile, setClientProfile] = useState();
  const [candidatContactOne, setCandidatContactOne] = useState(profile.props.candidatPhone != "" ? profile.props.candidatPhone.split(" ").join("") : "");
  const [candidatContactTwo, setCandidatContactTwo] = useState(profile.props.candidatAlternatePhone != "" ? profile.props.candidatAlternatePhone.split(" ").join("") : "");


  const setModalIsOpenToTrue = () => {
    setModalIsOpen(true)
  }

  const setModalIsOpenToFalse = () => {
    setModalIsOpen(false)
  }

  const fetchClientProfile = async (name: string) => {
    return await fetch(API_BASE_URL + `getClientByName/?clientCompanyName=${name}`, {
      method: "GET",
      headers: {
        "Accept": 'application/json',
        "Authorization": "Bearer " + localStorage.getItem('token')
      }
    })
      .then(resD => resD.json())
      .then(reD => reD)
      .catch(err => err)
  }

  const showCustomerProfile = async () => {
    console.log(clientProfile)
    if (Object.values(clientProfile).includes("To-Do")) {
      navigate("/clientToDoProfile", { state: clientProfile })
    } else if (Object.values(clientProfile).includes("In-Progress")) {
      navigate("/clientInProgressProfile", { state: clientProfile })
    } else if (Object.values(clientProfile).includes("Signed Contract")) {
      navigate("/clientSigned", { state: clientProfile })
    } else if (Object.values(clientProfile).includes("Archived")) {
      navigate("/clientSigned", { state: clientProfile })
    }
  }


  useEffect(() => {
    fetchClientProfile(profile.props.candidatCurrentWork[0].workingFor)
      .then(result => {
        if (result.status) {
          setClientProfile(result.data)
        }
      })
      .catch(err => {
        console.log(err)
      })
    console.log(profile);
  }, [profile]);

  const editCandidatProfile = () => {
    navigate("/editInProgress", { state: profile.props });
  }


  return (
    <>
      <div className="containet-fluid">
        <div className="row">
          <div className="col-12 top-pd text-center">
            <h1 style={{ textDecoration: "underline" }}>CANDIDAT: {profile.props.candidatName}</h1>
          </div>
          <div className="col-6">
            <div className="stable">
              <Link to="/embauchlist">
                <button type="button" className="btn bg-Progress-btn">
                  <img src={require("../images/return.svg").default} />
                  Return to - IN PROGRESS list of candidates
                </button>
              </Link>
            </div>
          </div>
          <div className="col-6  text-end ">
            <button className="btn btn-edit-bgb" onClick={editCandidatProfile}>
              <img src={require("../images/Edit.svg").default} />
              Edit Profile
            </button>

          </div>
          <div className="bg-class">
            <div className="col-12 p-3 bg-color-card">
              <div className="row">
                <div className="col-2 text-center ">
                  <img
                    src={profile.props.candidatPhoto ? API_BASE_URL + profile.props.candidatPhoto.data : require("../images/card-men.svg").default}
                    style={{ width: "90%" }}
                  />

                  {/* <button type="button" className="btn btn-upload">
                    UPLOAD PHOTO
                  </button> */}
                </div>
                <div className="col-5 card-xl">
                  <p>Name : <b>{profile.props.candidatName}</b></p>
                  <p>Age : <b>{profile.props.candiatAge}</b></p>
                  <div>

                    <p>
                      Motivation:
                      <StarRatings
                        rating={profile.props.candidatMotivation}
                        starRatedColor="#ffc107"
                        // changeRating={}
                        numberOfStars={profile.props.candidatMotivation}
                        starDimension={"19px"}
                        starSpacing={"1px"}
                        name="rating"
                      />
                    </p>
                  </div>
                  <p>Secteur : <b>{profile.props.candidatActivitySector}</b></p>
                  <p>Métier/Job : <b>{profile.props.candidatJob}</b></p>
                </div>
                <div className="col-5 text-end end-class">
                  <div>

                    <button type="button" className="btn btn-in-progress">
                      IN PROGRESS
                    </button>
                  </div>
                  <p className="fw-bold">Contrat en cours avec Intermann</p>
                  <p>This candidate have active contract with us</p>
                </div>
              </div>
            </div>
            <div className="col-12 boxProgress">
              <div className="row">
                <div className="col-4 d-flex justify-content-center">
                  <div className="workFont"><p>Works For </p>: <span>{profile.props.candidatCurrentWork[0].workingFor}</span></div>
                </div>
                <div className="col-4 d-flex justify-content-center">
                  <div className="workFont"><p>Since </p>: <span>{profile.props.candidatCurrentWork[0].workingSince}</span></div>
                </div>
                <div className="col-4 d-flex justify-content-center">
                  <div className="workFont"><p>Salary  </p>: <span>{profile.props.candidatCurrentWork[0].salary + " "}</span>€</div>
                </div>

                <div className="d-flex justify-content-center">
                  <button className="btn customerBtn" onClick={showCustomerProfile}>
                    <span>
                      <img src={require("../images/littleeye.svg").default} />
                    </span>CUSTOMER PROFIL
                  </button>
                </div>



              </div>
            </div>
            <div className="col-12 social-box-size">
              <div className="row">
                <div className="col-6 text-center">
                  <p>Mail: {profile.props.candidatEmail}</p>
                  {
                    profile.props.candidatEmail != undefined ?
                      <button className="btn btn-email" onClick={() => { window.location.href = "mailto:" + profile.props.candidatEmail }}>
                        <a>
                          <span className="padding-email">
                            <img src={require("../images/gmail.svg").default} />
                          </span>
                          Send Email
                        </a>
                      </button> :
                      <button className="btn btn-email">
                        <a href="#">
                          <span className="padding-email">
                            <img src={require("../images/gmail.svg").default} />
                          </span>
                          No Email Available
                        </a>
                      </button>
                  }
                  <p>Facebook:</p>
                  {
                    profile.props.candidatFBURL != "" ?
                      <a href={profile.props.candidatFBURL} target="_blank" className="btn btn-primary btn-see">
                        <span className="padding-email">
                          <img src={require("../images/facebook.svg").default} />
                        </span>
                        See Profile
                      </a> :
                      <a href="#" className="btn btn-primary btn-see">
                        <span className="padding-email">
                          <img src={require("../images/facebook.svg").default} />
                        </span>
                        No Profile Available
                      </a>
                  }
                </div>

                <div className="col-6">
                  <p>Phone : {profile.props.candidatPhone}</p>
                  {
                    candidatContactOne != "" ?
                      <button className="btn btn-whatsapp btn-see">
                        <a href={`https://wa.me/${candidatContactOne}`} target="_blank">
                          <span className="padding-email">
                            <img src={require("../images/whatsapp.svg").default} />
                          </span>
                          Send What’s App
                        </a>
                      </button> :
                      <button className="btn btn-whatsapp btn-see">
                        <a href="#">
                          <span className="padding-email">
                            <img src={require("../images/whatsapp.svg").default} />
                          </span>
                          Number Not Available
                        </a>
                      </button>
                  }
                  <p> Phone 2 : {profile.props.candidatAlternatePhone}</p>
                  {
                    candidatContactTwo != "" ?
                      <button className="btn btn-whatsapp btn-see">
                        <a href={`https://wa.me/${profile.candidatAlternatePhone}`} target="_blank">
                          <span className="padding-email">
                            <img src={require("../images/whatsapp.svg").default} />
                          </span>
                          Send What’s App
                        </a>
                      </button> :
                      <button className="btn btn-whatsapp btn-see">
                        <a href="#">
                          <span className="padding-email">
                            <img src={require("../images/whatsapp.svg").default} />
                          </span>
                          Number Not Available
                        </a>
                      </button>
                  }
                </div>
              </div>
            </div>
            <div className="col-12">
              <div className="parent-p">
                <div className="d-flex">
                  <p>Langues : </p>
                  <span> {profile.props.candidatLanguages.join(", ")}</span>
                </div>
                <div className="d-flex ">
                  <p className="blue-text">Ready for work :</p>
                  <span className="blue-text">
                    From {profile.props.candidatStartDate} - To {profile.props.candidatEndDate}
                  </span>
                </div>
                <div className="d-flex">
                  <p>Permis :</p>
                  <span>{profile.props.candidatLicensePermis ? "Yes" : "No"}</span>
                </div>
                <div className="d-flex">
                  <p>Voyage en voiture :</p>
                  <span>{profile.props.candidatConduireEnFrance ? "Yes" : "No"}</span>
                </div>
                <div className="d-flex">
                  <p>Skills/note: </p>
                  <span>
                    {profile.props.candidatSkills}
                  </span>
                </div>
              </div>
            </div>
            <div className="col-12 pt-4">
              <h3 className="exp">Expérience du Candidat </h3>
              <table className="table table-bordered border-dark">
                <thead>
                  <tr>
                    <th scope="col">
                      Période (Exemple Janvier 2020 à Janvier 2021)
                    </th>
                    <th scope="col">Lieu de Travail (Exemple Paris)</th>
                    <th scope="col">
                      Travail Effectué (Exemple : Facadier Isolateur)
                    </th>
                  </tr>
                </thead>
                <tbody>
                  {
                    profile.props.candidatExperienceDetails.length > 0 &&
                      profile.props.candidatExperienceDetails[0].period != "" ?

                      (profile.props.candidatExperienceDetails.map((detail) =>
                        <tr>
                          <td>{detail.period}</td>
                          <td>{detail.location}</td>
                          <td>{detail.workDoneSample}</td>
                        </tr>
                      )
                      ) : (
                        <tr>
                          <td colSpan={3} className="text-center">
                            <p>No Experience Details Available!</p>
                            <button className="btn btn-primary" onClick={editCandidatProfile}>Edit Candidat To Add Experience Details!</button>
                          </td>
                        </tr>
                      )
                  }
                </tbody>
              </table>
              <div className="d-flex align-center child-p pt-3">
                <p>Années d’expériance : </p>
                <span>{profile.props.candidatYearsExperience}</span>
              </div>
              <div className="d-flex align-center child-p">
                <p>Ajouté par/Added by :</p>
                <span> {profile.props.enteredBy}</span>
              </div>

              <p className="f-text">
                Note : Who entered this candidates/employe on the database
              </p>
            </div>
            <div className="col-12">
              <div className="row">
                <div className="col-3 text-center">
                  <button type="button" className="btn btn-red" onClick={() => setShowArchiveModal(true)}>
                    Archive / Cancel
                  </button>
                  {showArchiveModal ?
                    <ArchivedModal props={profile.props} closeModal={setShowArchiveModal} path={"/todolist"} /> : null
                  }
                </div>
                <div className="col-3 text-center">
                  <button type="button" className="btn btn-black" onClick={editCandidatProfile}>
                    <img src={require("../images/Edit.svg").default} />
                    Edit Profile
                  </button>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </>
  );
}

export default ProgressCard;
