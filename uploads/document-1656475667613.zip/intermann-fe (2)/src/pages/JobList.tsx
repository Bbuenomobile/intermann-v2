import React, { useEffect, useState } from "react";
import "../CSS/AddSector.css";
import { Link } from "react-router-dom";
import { Toaster, toast } from 'react-hot-toast';
import { useLocation } from "react-router-dom";
import RenameJobModal from "../components/Modal/RenameJobModal";
import AddJobModal from "../components/Modal/Add_Modal";;

function JobList() {
    const { state } = useLocation();
    const [data, setData] = useState<any>(state);
    const [renameModalData, setRenameModalData] = useState({ associatedSector: "", jobName: "" });
    const [renameModal, setRenameModal] = useState(false);
    const [jobModalData, setJobModalData] = useState("")
    const [jobModal, setJobModal] = useState(false)

    useEffect(() => {
        console.log(state);
    });

    return (
        <>
            <Toaster position="top-right" />

            <div className="container">
                <div className="row">
                    <div className="col-12 flex-wrap">
                        <h1 className="titleAdd">ADD SECTOR/JOB</h1>
                    </div>

                    <div className="col-12 vw-Box">
                        <div className="row">
                            <div className="col-12 bg-light">
                                <div className="row">
                                    <div className="col-12">
                                        <div className="row">
                                            <div className="col-4 d-flex align-item-center mt-2">
                                                <Link to="/addNewSector">
                                                    <button
                                                        type="button"
                                                        className="btn"
                                                        style={{
                                                            backgroundColor: "#FE8700D9",
                                                            color: "#ffff",
                                                            fontWeight: "400",
                                                        }}
                                                    >
                                                        <img
                                                            src={require("../images/return.svg").default}
                                                            style={{ marginRight: "5px" }}
                                                        />
                                                        Return to list of Sectors
                                                    </button>
                                                </Link>
                                            </div>

                                            <div className="col-8">
                                                <h1 className="list-001">
                                                    List of Jobs for {data[0].associatedSector}
                                                </h1>
                                            </div>


                                        </div>
                                    </div>

                                    <div className="col-12 pt-3">
                                        {/* {sectorsList.length > 0 ? sectorsList.map((sector) => */}

                                        <div className="row">
                                            <ul style={{ listStyle: "none" }}>
                                                {
                                                    data?.map((e) => (

                                                        <li className="pt-2">
                                                            <div className="col-12 pd-lr">
                                                                <div className="row">
                                                                    <div className="col-6 text-start d-flex align-item-center">
                                                                        <p className="A0012"> {e.jobName}</p>
                                                                    </div>
                                                                    <div className="col-6 text-end">
                                                                        <button className="btn btn-resume"
                                                                            onClick={() => {
                                                                                setRenameModal(true);
                                                                                setRenameModalData({
                                                                                    associatedSector: e.associatedSector,
                                                                                    jobName: e.jobName
                                                                                });
                                                                            }}>
                                                                            Rename
                                                                        </button>

                                                                        {renameModal ? (
                                                                            <RenameJobModal
                                                                                props={renameModalData}
                                                                                closeModal={setRenameModal}
                                                                            />
                                                                        ) : null}
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </li>
                                                    ))
                                                }

                                            </ul>
                                        </div>

                                        <div className="col-12  pb-3">
                                            <div className="row ">
                                                <div className="col-12 text-center">
                                                    <button
                                                        className="btn btn-green"
                                                        onClick={() => {
                                                            setJobModal(true);
                                                            setJobModalData(data[0].associatedSector);
                                                        }}
                                                    >
                                                        Add a Job on {data[0].associatedSector}
                                                    </button>
                                                    {

                                                        jobModal ?
                                                            <AddJobModal props={jobModalData} closeModal={setJobModal} />
                                                            : null
                                                    }
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </>
    );
}
export default JobList;
