import React, { useEffect, useState } from "react";
import StarRatings from "react-star-ratings";
import { Link } from "react-router-dom";
import "../../CSS/inProgressCard.css";
import Modal from '../../components/Modal/InProgressModal'
import ClientProgressCard from "../ClientPages/ClientProgressCard";
import { API_BASE_URL } from "../../config/serverApiConfig";
import toast, { Toaster } from 'react-hot-toast';
import Loader from "../../components/Loader/loader";

declare namespace JSX {
  interface IntrinsicElements {
    "lottie-player": any;
  }
}

export default function ClientProgress() {

  const [sectors, setSectors] = useState([]);
  const [jobs, setJobs] = useState([]);
  const [profiles, setProfiles] = useState([]);
  const [filteredProfiles, setFilteredProfiles] = useState([]);
  const [defaultCard, setDefaultCard] = useState(false)
  const [viewFilteredProfiles, setViewFilteredProfiles] = useState([]);
  const [selectedSector, setSelectedSector] = useState("");
  const [onChangesector, setChange] = useState([]);
  const [selectedJob, setSelectedJob] = useState("");
  const [selectedLanguages, setSelectedLanguages] = useState([]);
  const [sectorField, setSectorField] = useState([])
  const [showCard, setShowCard] = useState(false)
  const [loader, setLoader] = useState(true);
  const [allProfiles, setAllProfiles] = useState(false)


  const fetchProfiles = async () => {
    return await fetch(API_BASE_URL + "allInProgressClients", {
      method: "GET",
      headers: {
        "Accept": 'application/json',
        'Content-Type': 'application/json',
        "Authorization": "Bearer " + localStorage.getItem('token')
      }
    })
      .then(resD => resD.json())
      .then(reD => reD)
      .catch(err => err)
  }

  const fetchAllSectors = async () => {
    return await fetch(API_BASE_URL + "fetchAllSectors", {
      method: "GET",
      headers: {
        "Accept": 'application/json',
        'Content-Type': 'application/json',
        "Authorization": "Bearer " + localStorage.getItem('token')
      }
    })
      .then(resp => resp.json())
      .then(respData => respData)
      .catch(err => err)
  }

  const fetchAllJobs = async (sector: string) => {
    return await fetch(API_BASE_URL + `fetchAllJobs/?sector=${sector}`, {
      method: "GET",
      headers: {
        "Accept": 'application/json',
        'Content-Type': 'application/json',
        "Authorization": "Bearer " + localStorage.getItem('token')
      }
    }).then(resD => resD.json())
      .then(reD => reD)
      .catch(err => err)
  }

  const handleSectorChange = (e: any) => {
    console.log(e.target.value);
    setSelectedSector(e.target.value);
    if (e.target.value === "Select Un Secteur") {
      return setDefaultCard(true);
    } else if (e.target.name === "candidatActivitySector") {
      let sectorField = e.target.value;
      setSectorField(sectorField)
      const onChangesector = profiles.filter((profile) => {
        return profile.candidatActivitySector == sectorField
      })
      setChange([...onChangesector]);
      setDefaultCard(true)
      setShowCard(true)
      setAllProfiles(true);
    }

    fetchAllJobs(e.target.value)
      .then(data => {
        console.log(data)
        setJobs([...data.data])
      })
      .catch(err => {
        console.log(err)
      })
  }

  const handleJobFilter = (job: any) => {
    let jobFilter = job.jobName;
    setSelectedJob(jobFilter);
    const filteredProfiles = profiles.filter((profile) => {
      return profile.candidatJob == jobFilter
    })
    setFilteredProfiles([...filteredProfiles]);
    setDefaultCard(true);
    setShowCard(false)
  }

  const getSelectedLanguage = (e: any) => {
    if (e.target.checked) {
      addLanguages(e.target.value);
    } else {
      removeLanguages(e.target.value);
      setDefaultCard(false);
    }
  }
  const addLanguages = (lang: string) => {
    setSelectedLanguages((prev) => ([...prev, lang]));
  }

  const removeLanguages = (lang: string) => {
    setSelectedLanguages(selectedLanguages.filter((l) => l !== lang));
  }


  // useEffect(() => {
  //   fetchProfiles();
  // }, []);

  useEffect(() => {
    if (profiles.length == 0) {
      fetchProfiles()
        .then(data => {
          console.log(data)
          setProfiles([...data])
        })
        .catch(err => {
          console.log(err)
        })
    }
    if (sectors.length == 0) {
      fetchAllSectors().then(data => {
        console.log(data.data);
        setSectors([...data.data]);
      })
        .catch(err => {
          console.log(err);
        })
    }
  }, [jobs])

  useEffect(() => {

  })

  const [modalIsOpen, setModalIsOpen] = useState(false);
  const setModalIsOpenToTrue = () => {
    setModalIsOpen(true)
  }

  const setModalIsOpenToFalse = () => {
    setModalIsOpen(false)
  }


  return (
    <>
      <Toaster position="top-right" />

      <div className="container-fluid">
        <div className="row ">
          <div className="col-12 text-center">
            <img src={require("../../images/progress.svg").default} style={{ width: "70%", paddingTop: "30px" }} />
            <p className="text-family">
              Ici vous avez la liste des sociétés sur lesquelles nous avons
              <span className="fw-bolder"> une recherche active en cours.</span>
            </p>
            <p className="child-text">
              Nous dépensons de l’argent et du temps pour toutes les sociétés dans cette liste. Si la recherche n’est plus d’actu alors l’archiver        </p>
            <p>
              Here you have the list of companies on which we have an active search in progress.        </p>
          </div>
          <div className="col-6">
            <p>Filtre Secteur d’activité</p>
            <div className="dropdown">
              <div aria-labelledby="dropdownMenuButton1">
                <select name="candidatActivitySector" className="form-select" onChange={handleSectorChange}>
                  <option>Select Un Secteur</option>
                  {
                    sectors && sectors.map((sector) =>
                      <option value={sector.sectorName}>
                        <a className="dropdown-item" href="#">
                          {sector.sectorName}
                        </a>
                      </option>
                    )
                  }

                </select>
              </div>
            </div>
            <p className="last-child">Filtre Langues du candidat</p>
            <div>
              <div>
                <input type="checkbox" name="language" value="Roumain" onClick={getSelectedLanguage} />
                <span className="ps-2">Roumain</span>
              </div>
              <div>
                <input type="checkbox" name="language" value="Francais" onClick={getSelectedLanguage} />
                <span className="ps-2">Français</span>
              </div>
              <div>
                <input type="checkbox" name="language" value="Anglais" onClick={getSelectedLanguage} />
                <span className="ps-2">Anglais</span>
              </div>
              <div>
                <input type="checkbox" name="language" value="Italien" onClick={getSelectedLanguage} />
                <span className="ps-2">Italien</span>
              </div>
              <div>
                <input type="checkbox" name="language" value="Russe" onClick={getSelectedLanguage} />
                <span className="ps-2">Russe</span>
              </div>
              <div>
                <input type="checkbox" name="language" value="Espagnol" onClick={getSelectedLanguage} />
                <span className="ps-2">Espagnol</span>
              </div>
              <div>
                <input type="checkbox" name="language" value="Autre" onClick={getSelectedLanguage} />
                <span className="ps-2">Autre</span>
              </div>
            </div>
          </div>
          <div className="col-6">
            <p>Filtre selection métier / job</p>
            <div className="box">
              <ul className="list-group">
                {
                  jobs.length > 0 ? jobs.map((job) =>
                    <li className="job-ul list-group-item list-group-item-action" onClick={handleJobFilter}>

                      <a href="#">{job.jobName}</a>
                    </li>
                  ) : <p>Please Select a Sector to view Jobs!</p>
                }
              </ul>
            </div>
          </div>
          <hr className="new5" />
          {allProfiles ?
            <>
              {
                showCard ?
                  <>
                    {
                      defaultCard ?
                        onChangesector.length > 0 ?
                          onChangesector.map((profile) => (

                            <div className="col-4 mt-2 pd-left">
                              <ClientProgressCard data={profile} />
                            </div>
                          ))
                          :
                          viewFilteredProfiles.length > 0
                            ? viewFilteredProfiles.map((filteredProfile) => (
                              <div className="col-4 mt-2 pd-left">
                                <ClientProgressCard data={filteredProfile} />
                              </div>
                            ))
                            :
                            <p className="text-center">No Leads in Client In-Progress! Please Move New Client/Job Leads.</p>
                        :
                        profiles.map((profile) => (
                          <div className="col-4 mt-2 pd-left">
                            <ClientProgressCard data={profile} />
                          </div>
                        ))

                    }
                  </>
                  :
                  <>
                    {
                      filteredProfiles.length > 0 ?
                        filteredProfiles.map((filteredProfiles) => (
                          <div className="col-4 mt-2 pd-left">
                            <ClientProgressCard data={filteredProfiles} />
                          </div>
                        ))
                        : <p className="text-center">No Leads in Client In-Progress! Please Move New Client/Job Leads.</p>
                    }
                  </>
              }

            </> :
            profiles.length > 0 ?
              profiles.map((profile) => (
                <div className="col-4 mt-2 pd-left">
                  <ClientProgressCard data={profile} />
                </div>
              ))
              : <>
                {
                  loader ? (
                    <div className="col-12">
                      <div className="row d-flex justify-content-center">
                        <Loader />
                      </div>
                    </div>
                  )
                    :
                    <p className="text-center">No Leads in Client In-Progress! Please Move Client/Job Leads.</p>
                }
              </>

          }

        </div>
      </div>
    </>
  );
}

