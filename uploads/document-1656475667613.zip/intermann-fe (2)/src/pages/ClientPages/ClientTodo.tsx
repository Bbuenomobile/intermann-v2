import React, { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import StarRatings from 'react-star-ratings';
import "../../CSS/Client/ClientTodo.css";
import ClientToDoCard from "../../pages/ClientPages/ClientTodoCard";
import { Toaster } from 'react-hot-toast';
import Loader from "../../components/Loader/loader";
import { API_BASE_URL } from '../../config/serverApiConfig';


declare namespace JSX {
  interface IntrinsicElements {
    "lottie-player": any;
  }
}

function ClientToDoList() {

  const [loader, setLoader] = useState(true);
  const [profiles, setProfiles] = useState([]);
  const [sectors, setSectors] = useState([]);
  const [jobs, setJobs] = useState([]);
  const [selectedJob, setSelectedJob] = useState("");
  const [defaultCard, setDefault] = useState(false)
  const [selectedSector, setSelectedSector] = useState("");
  const [selectedLanguages, setSelectedLanguages] = useState([]);
  const [sectorField, setSectorField] = useState([])
  const [showCard, setShowCard] = useState(false)
  const [allProfiles, setAllProfiles] = useState(false)
  const [onChangesector, setChange] = useState([]);
  const [filteredProfiles, setFilteredProfiles] = useState([]);
  const [viewFilteredProfiles, setViewFilteredProfiles] = useState([]);

  const fetchAllSectors = async () => {
    return await fetch(API_BASE_URL + "fetchAllSectors", {
      method: "GET",
      headers: {
        "Accept": 'application/json',
        'Content-Type': 'application/json',
        "Authorization": "Bearer " + localStorage.getItem('token')
      }
    })
      .then(resp => resp.json())
      .then(respData => respData)
      .catch(err => err)
  }

  const fetchAllJobs = async (sector: string) => {
    if (sector === "Select Un Secteur") {
      return {
        data: []
      }
    }
    return await fetch(API_BASE_URL + `fetchAllJobs/?sector=${sector}`, {
      method: "GET",
      headers: {
        "Accept": 'application/json',
        'Content-Type': 'application/json',
        "Authorization": "Bearer " + localStorage.getItem('token')
      }
    }).then(resD => resD.json())
      .then(reD => reD)
      .catch(err => err)
  }

  const fetchProfiles = async () => {
    return await fetch(API_BASE_URL + "allToDoClients", {
      method: "GET",
      headers: {
        "Accept": 'application/json',
        "Authorization": "Bearer " + localStorage.getItem('token')
      }
    })
      .then(resD => resD.json())
      .then(reD => reD)
      .catch(err => err)
  }

  const handleJobFilter = (e: any) => {
    console.log(e.target.text)
    if (e.target.text == "Select Un Secteur") {
      setDefault(false)
      return;
    }
    let jobFilter = e.target.text;
    setSelectedJob(jobFilter);
    const filteredProfiles = profiles.filter((profile) => {
      return profile.candidatJob == jobFilter
    })
    console.log(filteredProfiles);
    setFilteredProfiles([...filteredProfiles]);
    setDefault(true);
    setShowCard(false)

  }

  const handleSectorChange = (e: any) => {
    console.log(e.target.value);
    setSelectedSector(e.target.value);
    if (e.target.value === "Select Un Secteur") {
      return setDefault(false);
    } else if (e.target.name === "clientActivitySector") {
      let sectorField = e.target.value;
      setSectorField(sectorField)
      const onChangesector = profiles.filter((profile) => {
        return profile.candidatActivitySector == sectorField
      })
      setChange([...onChangesector]);
      setDefault(true)
      setShowCard(true)
      setAllProfiles(true)
    }
    fetchAllJobs(e.target.value).then(data => {
      console.log(data)
      setJobs([...data.data])
    })
      .catch(err => {
        console.log(err)
      })
  }

  const getSelectedLanguage = (e: any) => {
    if (e.target.checked) {
      addLanguages(e.target.value);
    } else {
      removeLanguages(e.target.value);
      setDefault(false);
    }
  }

  const addLanguages = (lang: string) => {
    setSelectedLanguages((prev) => ([...prev, lang]));
  }

  const removeLanguages = (lang: string) => {
    setSelectedLanguages(selectedLanguages.filter((l) => l !== lang));
  }

  useEffect(() => {
    if (profiles.length == 0) {
      fetchProfiles()
        .then(data => {
          console.log(data)
          setProfiles([...data])
        })
        .catch(err => {
          console.log(err)
        })
    }
    if (sectors.length == 0) {
      fetchAllSectors().then(data => {
        console.log(data.data);
        setSectors([...data.data]);
      })
        .catch(err => {
          console.log(err);
        })
    }
  }, [jobs])

  return (
    <>
      <Toaster position="top-right" />
      <div className="container-fluid">
        <div className="row pd ">
          <div className="col-12 text-center">
            <img
              src={require("../../images/lead.svg").default}
              style={{ width: "70%" }}
            />
            <p className="text-family">
              Ici vous avez la liste des sociétés qui font une
              <span className="fw-bolder"> demande pas encore traité</span>
            </p>
            <p className="child-text">
              Vous devez toujours vous assurer d’avoir un maximum d’information sur cette liste et déplacer les leads en archive si plus d’actualité
            </p>
            <p>
              You should always make sure you have as much information as possible on this list and move the candidates to the archive if the candidate is not serious.
            </p>
          </div>
          <div className="col-6">
            <p>Filtre Secteur d’Activité</p>
            <div className="dropdown">
              <div aria-labelledby="dropdownMenuButton1">
                <select name="clientActivitySector" className="form-select" onChange={handleSectorChange}>
                  <option>Select Un Secteur</option>
                  {
                    sectors && sectors.map((sector) =>
                      <option value={sector.sectorName}>
                        <a className="dropdown-item" href="#">
                          {sector.sectorName}
                        </a>
                      </option>
                    )
                  }

                </select>
              </div>
            </div>
            <p className="last-child">Filtre Langues du candidat</p>
            <div>
              <div>
                <input type="checkbox" name="language" value="Roumain" onClick={getSelectedLanguage} />
                <span className="ps-2">Roumain</span>
              </div>
              <div>
                <input type="checkbox" name="language" value="Francais" onClick={getSelectedLanguage} />
                <span className="ps-2">Français</span>
              </div>
              <div>
                <input type="checkbox" name="language" value="Anglais" onClick={getSelectedLanguage} />
                <span className="ps-2">Anglais</span>
              </div>
              <div>
                <input type="checkbox" name="language" value="Italien" onClick={getSelectedLanguage} />
                <span className="ps-2">Italien</span>
              </div>
              <div>
                <input type="checkbox" name="language" value="Russe" onClick={getSelectedLanguage} />
                <span className="ps-2">Russe</span>
              </div>
              <div>
                <input type="checkbox" name="language" value="Espagnol" onClick={getSelectedLanguage} />
                <span className="ps-2">Espagnol</span>
              </div>
              <div>
                <input type="checkbox" name="language" value="Autre" onClick={getSelectedLanguage} />
                <span className="ps-2">Autre</span>
              </div>
            </div>
          </div>
          <div className="col-6">
            <p>Filtre selection métier / job</p>
            <div className="box">
              <ul className="list-group">
                {
                  jobs.length > 0 ? jobs.map((job) =>
                    <li className="job-ul list-group-item list-group-item-action" onClick={handleJobFilter}>

                      <a href="#">{job.jobName}</a>
                    </li>
                  ) : <p>Please Select a Sector to view Jobs!</p>
                }
              </ul>
            </div>
          </div>
          <hr className="new5" />
          {allProfiles ?
            <>
              {
                showCard ?
                  <>
                    {
                      defaultCard ?
                        onChangesector.length > 0 ?
                          onChangesector.map((profile) => (

                            <div className="col-4 mt-2 pd-left">
                              <ClientToDoCard data={profile} />
                            </div>
                          ))
                          :
                          viewFilteredProfiles.length > 0
                            ? viewFilteredProfiles.map((filteredProfile) => (
                              <div className="col-4 mt-2 pd-left">
                                <ClientToDoCard data={filteredProfile} />
                              </div>
                            ))
                            :
                            <p className="text-center">No Leads in Client To-Do! Please Add New Client/Job Leads.</p>
                        :
                        profiles.map((profile) => (
                          <div className="col-4 mt-2 pd-left">
                            <ClientToDoCard data={profile} />
                          </div>
                        ))

                    }
                  </>
                  :
                  <>
                    {
                      filteredProfiles.length > 0 ?
                        filteredProfiles.map((filteredProfiles) => (
                          <div className="col-4 mt-2 pd-left">
                            <ClientToDoCard data={filteredProfiles} />
                          </div>
                        ))
                        : <p className="text-center">No Leads in Client To-Do! Please Add New Client/Job Leads.</p>
                    }
                  </>
              }

            </> :
            profiles.length > 0 ?
              profiles.map((profile) => (
                <div className="col-4 mt-2 pd-left">
                  <ClientToDoCard data={profile} />
                </div>
              ))
              : <>
                {
                  loader ? (
                    <div className="col-12">
                      <div className="row d-flex justify-content-center">
                        <Loader />
                      </div>
                    </div>
                  )
                    :
                    <p className="text-center">No Leads in Client To-Do! Please Add New Client/Job Leads.</p>
                }
              </>

          }
        </div>
      </div>
    </>
  );
}
export default ClientToDoList;
